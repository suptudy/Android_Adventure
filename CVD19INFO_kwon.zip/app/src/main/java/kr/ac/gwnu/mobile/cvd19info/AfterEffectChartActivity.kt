package kr.ac.gwnu.mobile.cvd19info

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.text.Layout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.Chart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import kotlinx.android.synthetic.main.after_effect_chart_layout.view.*
import kotlinx.android.synthetic.main.toolbar.*
import com.github.mikephil.charting.data.ChartData as ChartData

class AfterEffectChartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.after_effect_chart_layout)

        setSupportActionBar(my_toolbar) // 툴바를 액티비티의 앱바로 지정
        supportActionBar?.setDisplayHomeAsUpEnabled(true) // 드로어를 꺼낼 홈 버튼 활성화
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_backspace_white) // 홈버튼 이미지 변경
        supportActionBar?.setDisplayShowTitleEnabled(false) // 툴바에 타이틀 안보이게
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            var btnAEC = findViewById<Button>(R.id.btnAEC)
            var pieChart = findViewById<View>(R.id.piechart)

            btnAEC.setOnClickListener {
                var aeArray = arrayOf("피로", "호흡곤란", "관절통증") //후유증 추가
                var selectedArray = ArrayList<Int>() //체크박스 체크 넣을 것
                var dlg = AlertDialog.Builder(this)
                dlg.setTitle("코로나 후유증 종류를 선택하세요")
                    //dlg.setIcon() //제목 옆 아이콘 설정
                    // Specify the list array, the items to be selected by default (null for none),
                    // and the listener through which to receive callbacks when items are selected
                    .setMultiChoiceItems(aeArray, null,
                        DialogInterface.OnMultiChoiceClickListener { dialog, which, isChecked ->
                            if (isChecked) {
                                selectedArray.add(which)
                            } else if (selectedArray.contains(which)) {
                                selectedArray.remove(Integer.valueOf(which))
                            } //선택한 항목 selectedArray에 저장
                        })

                    .setPositiveButton("완료",
                        DialogInterface.OnClickListener { dialog, id ->
                            // User clicked OK, so save the selectedItems results somewhere
                            // or return them to the component that opened the dialog
                            //완료 누르면 파이 차트에 나올 수 있게
                        })

                dlg.create()
            } ?: throw IllegalStateException("Activity cannot be null")
        }
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home->{ // 메뉴 버튼
                super.onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }


