package kr.ac.gwnu.clockrona

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import kotlinx.android.synthetic.main.after_effect.view.*

class Frag2 : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val btnAE = view?.findViewById<Button>(R.id.btnAE)
        btnAE?.setOnClickListener{
            onCreateDialog()
        }
    }

    private fun onCreateDialog() {
        val aeArray = arrayOf("피로","호흡곤란","미각장애")
        val selectItems = ArrayList<Int>()
        val builder = AlertDialog.Builder(this)
            builder.setTitle("후유증 종류를 선택하세요")
            builder.setMultiChoiceItems(aeArray, null) { dialog, which, isChecked ->
                if(isChecked) {
                    selectItems.add(which)
                } else if(selectItems.contains(which)) {
                    selectItems.remove((Integer.valueOf(which)))
                }
            }
                .setPositiveButton(R.string.ok,
                    DialogInterface.OnClickListener { dialog, id ->
                        //라디오버튼에서 선택 후 완료버튼 누르면 원형차트에 연결될 수 있게
                    })
        builder.create()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view =  inflater.inflate(R.layout.after_effect, container, false)

        val yValues: ArrayList<PieEntry> = ArrayList()
        with(yValues) {
            add(PieEntry(18.5f, "Green"))
            add(PieEntry(26.7f, "Yellow"))
            add(PieEntry(24.0f, "Red"))
            add(PieEntry(30.8f, "Blue"))
        }

        val set: PieDataSet = PieDataSet(yValues, "Election Results")
        val pieData: PieData = PieData(set)
        view.piechart.data = pieData
        view.piechart.invalidate()


        return view
    }
}

